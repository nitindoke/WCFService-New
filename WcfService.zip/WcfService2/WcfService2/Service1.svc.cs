﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Data.Entity;
using System.Text;

namespace WcfService2
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
         public List<Student> GetStudentDetails()
        {
            List<Student> stuList = new List<Student>();

            using (SchoolEntities sc = new SchoolEntities())
            {
                stuList = sc.Students.Where(i => i.id != 0).ToList();
            }
            return stuList;
         }

         public Student GetStudentDetailsById(int id)
         {
             Student stu = new Student();

             using (SchoolEntities sc = new SchoolEntities())
             {
                 stu = sc.Students.Where(i => i.id == id).FirstOrDefault();
             }
             return stu;
         }

         public bool PostStudentDetails(Student stu)
         {
             using (SchoolEntities sc = new SchoolEntities())
             {
                 if (stu != null && stu.name != null)
                 {
                     sc.Students.Add(stu);
                     sc.SaveChanges();
                 }
             }
             
             return true;
         }
    }
}
